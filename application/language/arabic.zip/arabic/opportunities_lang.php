<?php
$lang['opportunities'] = '';
$lang['opportunities_state_reason'] = '';
$lang['opportunities_state'] = '';
$lang['stages'] = '';
$lang['won'] = '';
$lang['abandoned'] = '';
$lang['suspended'] = '';
$lang['lost'] = '';
$lang['negotiation'] = '';
$lang['update'] = 'حفظ';
$lang['all_opportunities'] = '';
$lang['new_opportunities'] = '';
$lang['opportunity_name'] = '';
$lang['qualification'] = '';
$lang['proposition'] = '';
$lang['dead'] = '';
$lang['probability'] = '';
$lang['close_date'] = '';
$lang['who_responsible'] = '';
$lang['expected_revenue'] = '';
$lang['new_link'] = '';
$lang['next_action'] = '';
$lang['next_action_date'] = '';
$lang['current_state'] = '';
$lang['change_state'] = '';
$lang['opportunity_details'] = '';
$lang['activity_update_opportunity'] = '';
$lang['update_opportunity'] = '';
$lang['activity_save_opportunity'] = '';
$lang['save_opportunity'] = '';
$lang['save_opportunity_call'] = '';
$lang['activity_save_opportunity_call'] = '';
$lang['activity_update_opportunity_call'] = '';
$lang['update_opportunity_call'] = '';
$lang['activity_opportunity_call_deleted'] = '';
$lang['opportunity_call_deleted'] = '';
$lang['save_opportunity_metting'] = '';
$lang['activity_save_opportunity_metting'] = '';
$lang['activity_update_opportunity_metting'] = '';
$lang['update_opportunity_metting'] = '';
$lang['activity_opportunity_metting_deleted'] = '';
$lang['opportunity_metting_deleted'] = '';
$lang['activity_new_opportunity_comment'] = '';
$lang['opportunity_comment_save'] = '';
$lang['task_comment_deleted'] = '';
$lang['opportunity_file_updated'] = '';
$lang['opportunity_file_added'] = '';
$lang['activity_new_opportunity_attachment'] = '';
$lang['opportunity_attachfile_deleted'] = '';
$lang['activity_opportunity_attachfile_deleted'] = '';
$lang['opportunity_deleted'] = '';
$lang['activity_opportunity_deleted'] = '';


/* End of file opportunities_lang.php */
/* Location: ./application/language/arabic/opportunities_lang.php */
