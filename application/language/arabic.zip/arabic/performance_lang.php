<?php
$lang['performance'] = '';
$lang['performance_indicator'] = '';
$lang['give_appraisal'] = '';
$lang['performance_report'] = '';
$lang['indicator_list'] = '';
$lang['set_indicator'] = '';
$lang['technical_competency'] = '';
$lang['customer_experience_management'] = '';
$lang['beginner'] = '';
$lang['intermediate'] = '';
$lang['advanced'] = '';
$lang['expert_leader'] = '';
$lang['marketing'] = '';
$lang['management'] = '';
$lang['administration'] = '';
$lang['presentation_skill'] = '';
$lang['quality_of_work'] = '';
$lang['efficiency'] = '';
$lang['behavioural_competency'] = '';
$lang['integrity'] = '';
$lang['professionalism'] = '';
$lang['team_work'] = '';
$lang['critical_thinking'] = '';
$lang['conflict_management'] = '';
$lang['attendance'] = 'الحضور';
$lang['ability_to_meet_deadline'] = '';
$lang['activity_performance_indicator_saved'] = '';
$lang['activity_performance_indicator_updated'] = '';
$lang['indicator_update'] = '';
$lang['indicator_saved'] = '';
$lang['performance_indicator_details'] = '';
$lang['indicator_value_not_set'] = '';
$lang['give_performance_appraisal'] = '';
$lang['remarks'] = '';
$lang['expected_value'] = '';
$lang['set_value'] = '';
$lang['not_set'] = '';
$lang['appraisal_already_provided'] = '';
$lang['activity_appraisal_update'] = '';
$lang['activity_appraisal_saved'] = '';
$lang['appraisal_update'] = '';
$lang['appraisal_saved'] = '';
$lang['emp_id'] = '#';
$lang['appraisal_month'] = '';
$lang['performance_appraisal_details'] = '';
$lang['performance_appraisal_of'] = '';
$lang['assigned'] = '';
$lang['expected'] = '';
$lang['atleast_one_appraisal'] = '';


/* End of file performance_lang.php */
/* Location: ./application/language/arabic/performance_lang.php */
