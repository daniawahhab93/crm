<?php
$lang['menu_permission'] = 'قائمة الأذونات';
$lang['module'] = 'وحدة';
$lang['department_update'] = 'تم التحديث بنجاح';
$lang['designation_info_deleted'] = 'تم الحذف بنجاح';
$lang['department_info_deleted'] = 'تم الحذف بنجاح';
$lang['no_designation_create_yet'] = 'لم يتم انشاء مسمى وظيفي';
$lang['department_already_used'] = 'لا يمكن حذف القسم، لانه مرتبط ببيانات موظفين';
$lang['designation_already_used'] = 'هذا المسمى الوظيفي تم ربطه مع موظف سابق';
$lang['undefined_department'] = 'قسم غير معروف';
$lang['activity_update_a_department'] = 'تحديث القسم';
$lang['activity_delete_a_department'] = 'حذف القسم';
$lang['activity_delete_a_designation'] = 'مسمى وظيفي محذوف';
$lang['create'] = 'انشاء';
$lang['view_help'] = 'اذا قمت باختيار (انشاء - تعديل - حذف) فلا حاجة لاختيار عرض';
$lang['set_full_permission'] = 'اضافة كافة الصلاحيات لهذا المسمى الوظيفي';


/* End of file departments_lang.php */
/* Location: ./application/language/arabic/departments_lang.php */
