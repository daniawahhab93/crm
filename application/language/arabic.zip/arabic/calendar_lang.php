<?php
$lang['cal_su'] = 'أحد';
$lang['cal_mo'] = 'اثنين';
$lang['cal_tu'] = 'ثلاثاء';
$lang['cal_we'] = 'أربعاء';
$lang['cal_th'] = 'خميس';
$lang['cal_fr'] = 'جمعة';
$lang['cal_sa'] = 'سبت';
$lang['cal_sun'] = 'أحد';
$lang['cal_mon'] = 'اثنين';
$lang['cal_tue'] = 'ثلاثاء';
$lang['cal_wed'] = 'أربعاء';
$lang['cal_thu'] = 'خميس';
$lang['cal_fri'] = 'جمعة';
$lang['cal_sat'] = 'سبت';
$lang['cal_sunday'] = 'أحد';
$lang['cal_monday'] = 'اثنين';
$lang['cal_tuesday'] = 'ثلاثاء';
$lang['cal_wednesday'] = 'أربعاء';
$lang['cal_thursday'] = 'خميس ';
$lang['cal_friday'] = 'جمعة';
$lang['cal_saturday'] = 'سبت';
$lang['cal_jan'] = 'يناير';
$lang['cal_feb'] = 'فبراير';
$lang['cal_mar'] = 'مارس';
$lang['cal_apr'] = 'أبريل';
$lang['cal_may'] = 'مايو';
$lang['cal_jun'] = 'يونيو';
$lang['cal_jul'] = 'يوليو';
$lang['cal_aug'] = 'أغسطس';
$lang['cal_sep'] = 'سبتمبر';
$lang['cal_oct'] = 'أكتوبر';
$lang['cal_nov'] = 'نوفمبر';
$lang['cal_dec'] = 'ديسمبر';
$lang['cal_january'] = 'يناير';
$lang['cal_february'] = 'فبراير';
$lang['cal_march'] = 'مارس';
$lang['cal_april'] = 'أبريل';
$lang['cal_mayl'] = 'مايو';
$lang['cal_june'] = 'يونيو';
$lang['cal_july'] = 'يوليو';
$lang['cal_august'] = 'أغسطس';
$lang['cal_september'] = 'سبتمبر';
$lang['cal_october'] = 'أكتوبر';
$lang['cal_november'] = 'نوفمبر';
$lang['cal_december'] = 'ديسمبر';


/* End of file calendar_lang.php */
/* Location: ./application/language/arabic/calendar_lang.php */
