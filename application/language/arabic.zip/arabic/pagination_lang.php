<?php
$lang['pagination_first_link'] = 'الأول >';
$lang['pagination_next_link'] = '>';
$lang['pagination_prev_link'] = '<';
$lang['pagination_last_link'] = 'الأخير <';


/* End of file pagination_lang.php */
/* Location: ./application/language/arabic/pagination_lang.php */
